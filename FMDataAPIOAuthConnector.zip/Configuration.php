<?php

	define ( 'SERVER', 'clickserver23.clickworks.eu');